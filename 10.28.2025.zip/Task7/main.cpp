#include <iostream>
using namespace std;
int main() {
    string first, last;
    cin >> first >> last;
    string full = first + " " + last;
    cout << "Full name = " << full;
    return 0;
}
